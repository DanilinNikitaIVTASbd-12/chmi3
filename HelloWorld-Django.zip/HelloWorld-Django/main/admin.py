from django.contrib import admin
from .models import *

admin.site.register(Product)
admin.site.register(Role)
admin.site.register(User)
admin.site.register(Basket)
admin.site.register(Receipt)
